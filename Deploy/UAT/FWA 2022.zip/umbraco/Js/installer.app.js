var app = angular.module('umbraco', [    
    'umbraco.directives',
    'umbraco.install',
    'ngCookies',
    'ngMobile',
    'ngSanitize'
]);